//Blocks for the AUTODUINO interface

/**
 * @license
 * GPL
 *
 * Copyright 2016 Bernard Remond.
 * https://github.com/nbremond77
 *
 */

/**
 * @fileoverview Helper functions for generating autoduino interface board.
 * @author nbremond@laposte.net (Bernard Remond)
 */

goog.provide('Blockly.Blocks.autoduino');

goog.require('Blockly.Blocks');


Blockly.Blocks['autoduino_button'] = {
  init: function() {
    this.setColour("#8B0000");
    this.setHelpUrl(Blockly.Msg.AUTODUINO_INOUT_BUTTON_HELPURL);
	this.appendDummyInput()
        .appendField(Blockly.Msg.AUTODUINO_INOUT_BUTTON_TEXT)
        .appendField(new Blockly.FieldImage(Blockly.pathToBlockly + 'blocks/autoduino/media/700x560_K-AP-MBP-M.jpg', Blockly.Arduino.imageSize, Blockly.Arduino.imageSize));
    this.appendDummyInput("")
        .setAlign(Blockly.ALIGN_RIGHT)
        .appendField(Blockly.Msg.AUTODUINO_INOUT_BUTTON_INPUT)
        .appendField(new Blockly.FieldDropdown(Blockly.Msg.AUTODUINO_OUT_IN),"PIN");
    this.setInputsInline(true);
    this.setOutput(true, 'Boolean');
    this.setTooltip(Blockly.Msg.AUTODUINO_INOUT_BUTTON_TOOLTIP);
  }
};


