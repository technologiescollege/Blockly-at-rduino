//Code generator functions for the AUTODUINO interface

/**
 * @license
 * GPL
 *
 * Copyright 2016 Bernard Remond.
 * https://github.com/nbremond77
 *
 */

/**
 * @fileoverview Helper functions for generating autoduino interface board.
 * @author nbremond@laposte.net (Bernard Remond)
 */

/**
 * @fileoverview Helper functions for generating seeeduino autoduino blocks.
 * @author gasolin@gmail.com (Fred Lin)
 */

//---------------------------------------------------


var code = "// no code";
/** ****************** CAPTEURS ******************************/

Blockly.Arduino.autoduino_button = function() {
    return [code, Blockly.Arduino.ORDER_ATOMIC];
};

